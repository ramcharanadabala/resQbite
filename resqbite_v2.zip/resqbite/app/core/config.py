"""
ResQBite – Core configuration
Loads settings from environment / .env file via pydantic-settings.
"""

from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    # App
    APP_NAME: str = "ResQBite"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "production"

    # Database
    DATABASE_URL: str = "mysql+pymysql://root:root@localhost:3306/resqbite_db"

    # JWT
    SECRET_KEY: str = "change-me-in-production-use-32-char-minimum"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # Business Logic
    NGO_CLAIM_WINDOW_MINUTES: int = 30   # NGO-only claim window before orphanages can claim

    # Rate Limiting
    RATE_LIMIT_PER_MINUTE: int = 60

    # Notifications
    NOTIFICATION_BACKEND: str = "mock"   # mock | redis | email


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
