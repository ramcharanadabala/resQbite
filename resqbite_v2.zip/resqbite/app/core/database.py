"""
ResQBite – Database engine & session management
"""

from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,          # detect stale connections
    pool_size=10,
    max_overflow=20,
    pool_recycle=3600,           # recycle connections every hour
    echo=settings.DEBUG,
)

# Enable MySQL strict mode & timezone consistency
@event.listens_for(engine, "connect")
def set_mysql_session_config(dbapi_conn, _):
    cursor = dbapi_conn.cursor()
    cursor.execute("SET time_zone = '+00:00'")
    cursor.execute("SET SESSION sql_mode = 'STRICT_TRANS_TABLES'")
    cursor.close()


SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    """Shared declarative base for all ORM models."""
    pass


def get_db():
    """FastAPI dependency – yields a DB session and ensures cleanup."""
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def init_db():
    """Create all tables (run once at startup)."""
    from app.models import user, food, claim, notification  # noqa: F401 – register models
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables initialised.")
