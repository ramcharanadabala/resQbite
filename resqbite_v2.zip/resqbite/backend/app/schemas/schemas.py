"""
ResQBite — Pydantic Schemas
Request/Response validation for all endpoints.
"""
from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum


# ── Shared ─────────────────────────────────────────────────────────────────────
class OkResponse(BaseModel):
    ok: bool = True
    message: str


# ── Auth ───────────────────────────────────────────────────────────────────────
class RegisterRequest(BaseModel):
    email: EmailStr
    full_name: str = Field(..., min_length=2, max_length=255)
    phone: Optional[str] = None
    password: str = Field(..., min_length=8, max_length=100)
    role: str = Field(..., pattern="^(donor|ngo|orphanage)$")
    organization_name: Optional[str] = None
    registration_no: Optional[str] = None
    address: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user_id: int
    role: str


class RefreshRequest(BaseModel):
    refresh_token: str


# ── User ───────────────────────────────────────────────────────────────────────
class UserBase(BaseModel):
    email: str
    full_name: str
    phone: Optional[str]
    role: str
    organization_name: Optional[str]
    address: Optional[str]
    latitude: Optional[float]
    longitude: Optional[float]
    is_active: bool
    is_verified: bool


class UserOut(UserBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    organization_name: Optional[str] = None
    address: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None


# ── Food ───────────────────────────────────────────────────────────────────────
class FoodCreate(BaseModel):
    title: str = Field(..., min_length=3, max_length=255)
    description: Optional[str] = None
    category: str = "other"
    quantity: str = Field(..., min_length=1)
    serves: Optional[int] = Field(None, ge=1)
    image_url: Optional[str] = None
    expiry_time: datetime
    pickup_by: Optional[datetime] = None
    pickup_address: Optional[str] = None
    latitude: float
    longitude: float
    is_vegetarian: bool = False
    is_vegan: bool = False
    is_halal: bool = False
    is_kosher: bool = False

    @validator("expiry_time")
    def expiry_must_be_future(cls, v):
        from datetime import timezone
        if v.replace(tzinfo=timezone.utc) <= datetime.now(timezone.utc):
            raise ValueError("expiry_time must be in the future")
        return v


class FoodUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    quantity: Optional[str] = None
    serves: Optional[int] = None
    pickup_address: Optional[str] = None
    image_url: Optional[str] = None


class FoodOut(BaseModel):
    id: int
    donor_id: int
    title: str
    description: Optional[str]
    category: str
    quantity: str
    serves: Optional[int]
    image_url: Optional[str]
    status: str
    expiry_time: datetime
    pickup_by: Optional[datetime]
    pickup_address: Optional[str]
    latitude: float
    longitude: float
    is_vegetarian: bool
    is_vegan: bool
    is_halal: bool
    is_kosher: bool
    ngo_window_open: bool
    ngo_window_expires_at: Optional[datetime]
    created_at: datetime
    distance_km: Optional[float] = None   # injected by geo service

    class Config:
        from_attributes = True


class FoodListResponse(BaseModel):
    total: int
    items: List[FoodOut]


# ── Claim ──────────────────────────────────────────────────────────────────────
class ClaimCreate(BaseModel):
    food_id: int
    notes: Optional[str] = None


class ClaimOut(BaseModel):
    id: int
    food_id: int
    claimer_id: int
    status: str
    notes: Optional[str]
    pickup_code: Optional[str]
    pickup_confirmed_at: Optional[datetime]
    claimed_at: datetime

    class Config:
        from_attributes = True


class PickupConfirm(BaseModel):
    pickup_code: str


# ── Notification ───────────────────────────────────────────────────────────────
class NotificationOut(BaseModel):
    id: int
    type: str
    title: str
    message: str
    is_read: bool
    reference_id: Optional[int]
    reference_type: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ── Admin ──────────────────────────────────────────────────────────────────────
class AdminStatsOut(BaseModel):
    total_users: int
    total_donors: int
    total_ngos: int
    total_orphanages: int
    total_food_listings: int
    available_food: int
    claimed_food: int
    picked_food: int
    expired_food: int
    total_claims: int
    successful_pickups: int


class UserAdminUpdate(BaseModel):
    is_active: Optional[bool] = None
    is_verified: Optional[bool] = None
    role: Optional[str] = None
