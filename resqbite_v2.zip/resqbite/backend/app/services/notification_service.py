"""
ResQBite — Notification Service
Mock implementation — swap the _dispatch method with Celery/Redis/SES for production.
"""
import logging
import random
import string
from sqlalchemy.orm import Session
from datetime import datetime, timezone

from app.models.notification import Notification, NotificationType
from app.models.user import User

logger = logging.getLogger(__name__)


class NotificationService:
    """
    Central notification dispatch.
    Currently logs notifications and stores in DB.
    Production: replace _dispatch with Celery task / SES / FCM.
    """

    def __init__(self, db: Session):
        self.db = db

    def send(
        self,
        user_id: int,
        ntype: NotificationType,
        title: str,
        message: str,
        reference_id: int = None,
        reference_type: str = None,
    ) -> Notification:
        notif = Notification(
            user_id=user_id,
            type=ntype,
            title=title,
            message=message,
            reference_id=reference_id,
            reference_type=reference_type,
        )
        self.db.add(notif)
        self.db.flush()  # get ID without committing

        self._dispatch(notif)
        return notif

    def _dispatch(self, notif: Notification):
        """
        Mock dispatch — logs to console.
        Replace with:
          - celery_app.send_task("send_email", args=[...])
          - boto3 SES for email
          - Firebase Admin SDK for push
        """
        logger.info(
            f"[NOTIFICATION] user_id={notif.user_id} "
            f"type={notif.type} title='{notif.title}'"
        )

    # ── Convenience helpers ─────────────────────────────────────────────────────
    def food_available(self, user_id: int, food_title: str, food_id: int):
        self.send(
            user_id=user_id,
            ntype=NotificationType.FOOD_AVAILABLE,
            title="New Food Available!",
            message=f"'{food_title}' is available for pickup near you.",
            reference_id=food_id,
            reference_type="food",
        )

    def claim_approved(self, user_id: int, food_title: str, claim_id: int, pickup_code: str):
        self.send(
            user_id=user_id,
            ntype=NotificationType.CLAIM_APPROVED,
            title="Claim Approved ✅",
            message=f"Your claim for '{food_title}' is approved. Pickup code: {pickup_code}",
            reference_id=claim_id,
            reference_type="claim",
        )

    def claim_rejected(self, user_id: int, food_title: str, claim_id: int):
        self.send(
            user_id=user_id,
            ntype=NotificationType.CLAIM_REJECTED,
            title="Claim Rejected",
            message=f"Your claim for '{food_title}' was rejected.",
            reference_id=claim_id,
            reference_type="claim",
        )

    def food_picked(self, donor_id: int, food_title: str, food_id: int):
        self.send(
            user_id=donor_id,
            ntype=NotificationType.PICKUP_REMINDER,
            title="Food Picked Up 🎉",
            message=f"'{food_title}' has been successfully picked up. Thank you for donating!",
            reference_id=food_id,
            reference_type="food",
        )


def generate_pickup_code(length: int = 6) -> str:
    return "".join(random.choices(string.digits, k=length))
