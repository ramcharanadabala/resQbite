"""
ResQBite — Background Scheduler
Handles auto-expiry of food listings and priority timer enforcement.
"""
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from datetime import datetime, timezone
import logging

from app.core.config import settings

logger = logging.getLogger(__name__)


def expire_stale_food():
    """Mark food listings as EXPIRED when their expiry_time has passed."""
    from app.core.database import SessionLocal
    from app.models.food import FoodListing, FoodStatus

    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc)
        expired = (
            db.query(FoodListing)
            .filter(
                FoodListing.status == FoodStatus.AVAILABLE,
                FoodListing.expiry_time <= now,
            )
            .all()
        )
        for food in expired:
            food.status = FoodStatus.EXPIRED
            logger.info(f"[Scheduler] Food #{food.id} '{food.title}' expired")

        # Also expire CLAIMED items if food itself is expired
        from app.models.claim import Claim, ClaimStatus
        claimed_expired = (
            db.query(FoodListing)
            .filter(
                FoodListing.status == FoodStatus.CLAIMED,
                FoodListing.expiry_time <= now,
            )
            .all()
        )
        for food in claimed_expired:
            food.status = FoodStatus.EXPIRED
            active_claim = (
                db.query(Claim)
                .filter(Claim.food_id == food.id, Claim.status == ClaimStatus.PENDING)
                .first()
            )
            if active_claim:
                active_claim.status = ClaimStatus.CANCELLED
            logger.info(f"[Scheduler] Claimed food #{food.id} expired, claim cancelled")

        if expired or claimed_expired:
            db.commit()
            logger.info(f"[Scheduler] Expired {len(expired) + len(claimed_expired)} listings")
    except Exception as e:
        db.rollback()
        logger.error(f"[Scheduler] Error in expire_stale_food: {e}")
    finally:
        db.close()


def enforce_ngo_priority_window():
    """
    After NGO_PRIORITY_WINDOW_MINUTES, open AVAILABLE food to Orphanage claims.
    We track this via FoodListing.ngo_window_expires_at.
    """
    from app.core.database import SessionLocal
    from app.models.food import FoodListing, FoodStatus

    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc)
        # Find listings where NGO window expired but food is still available
        listings = (
            db.query(FoodListing)
            .filter(
                FoodListing.status == FoodStatus.AVAILABLE,
                FoodListing.ngo_window_expires_at != None,
                FoodListing.ngo_window_expires_at <= now,
                FoodListing.ngo_window_open == True,
            )
            .all()
        )
        for food in listings:
            food.ngo_window_open = False  # Now orphanages can claim
            logger.info(f"[Scheduler] NGO window closed for food #{food.id}, opening to all")

        if listings:
            db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"[Scheduler] Error in NGO priority window: {e}")
    finally:
        db.close()


def start_scheduler() -> BackgroundScheduler:
    scheduler = BackgroundScheduler(timezone="UTC")

    scheduler.add_job(
        expire_stale_food,
        trigger=IntervalTrigger(seconds=settings.EXPIRY_CHECK_INTERVAL_SECONDS),
        id="expire_food",
        name="Auto-expire food listings",
        replace_existing=True,
    )

    scheduler.add_job(
        enforce_ngo_priority_window,
        trigger=IntervalTrigger(seconds=30),
        id="ngo_priority",
        name="Enforce NGO priority window",
        replace_existing=True,
    )

    scheduler.start()
    logger.info("[Scheduler] Started background jobs")
    return scheduler
