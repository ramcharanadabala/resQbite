"""
ResQBite — Core Configuration
All settings loaded from environment variables with sensible defaults.
"""
from pydantic_settings import BaseSettings
from typing import List
import os


class Settings(BaseSettings):
    # ── App ───────────────────────────────────────────────────────────────────
    APP_NAME: str = "ResQBite"
    DEBUG: bool = False
    SECRET_KEY: str = "CHANGE_ME_IN_PRODUCTION_USE_256_BIT_RANDOM_KEY"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # ── Database ──────────────────────────────────────────────────────────────
    DB_HOST: str = "localhost"
    DB_PORT: int = 3306
    DB_USER: str = "root"
    DB_PASSWORD: str = "password"
    DB_NAME: str = "resqbite"

    @property
    def DATABASE_URL(self) -> str:
        return (
            f"mysql+pymysql://{self.DB_USER}:{self.DB_PASSWORD}"
            f"@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
        )

    # ── CORS ──────────────────────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8080",
        "http://127.0.0.1:8000",
    ]

    # ── Business Rules ────────────────────────────────────────────────────────
    # How long NGO has exclusive claim window (minutes) before Orphanages can claim
    NGO_PRIORITY_WINDOW_MINUTES: int = 30
    # Auto-expire check interval (seconds)
    EXPIRY_CHECK_INTERVAL_SECONDS: int = 60
    # Max food listings per donor per hour (rate limiting)
    MAX_FOOD_LISTINGS_PER_HOUR: int = 10
    # Geo radius default (km)
    DEFAULT_SEARCH_RADIUS_KM: float = 25.0

    # ── Notifications ─────────────────────────────────────────────────────────
    NOTIFICATION_QUEUE_BACKEND: str = "mock"  # mock | redis | celery
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
