"""
ResQBite — Claims Router
POST   /claims/             Submit a claim
GET    /claims/             List my claims
GET    /claims/{id}         Claim detail
PATCH  /claims/{id}/approve Donor approves claim
PATCH  /claims/{id}/reject  Donor rejects claim
POST   /claims/{id}/pickup  Confirm pickup with OTP
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timezone
import logging

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.food import FoodListing, FoodStatus
from app.models.claim import Claim, ClaimStatus
from app.models.user import UserRole
from app.schemas.schemas import ClaimCreate, ClaimOut, PickupConfirm
from app.services.notification_service import NotificationService, generate_pickup_code

router = APIRouter()
logger = logging.getLogger(__name__)


@router.post("/", response_model=ClaimOut, status_code=201)
def create_claim(
    payload: ClaimCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    Submit a claim for a food listing.
    Enforces NGO priority window: Orphanages cannot claim while ngo_window_open=True.
    """
    if current_user.role not in (UserRole.NGO, UserRole.ORPHANAGE):
        raise HTTPException(status_code=403, detail="Only NGOs and Orphanages can claim food")

    food = db.query(FoodListing).filter(FoodListing.id == payload.food_id).first()
    if not food:
        raise HTTPException(status_code=404, detail="Food listing not found")
    if food.status != FoodStatus.AVAILABLE:
        raise HTTPException(status_code=400, detail=f"Food is {food.status}, not available")

    # ── Priority Check ─────────────────────────────────────────────────────────
    if current_user.role == UserRole.ORPHANAGE and food.ngo_window_open:
        remaining = (food.ngo_window_expires_at - datetime.now(timezone.utc)).seconds // 60
        raise HTTPException(
            status_code=403,
            detail=f"NGO priority window active. Orphanages can claim in ~{remaining} minutes.",
        )

    # ── Duplicate Check ────────────────────────────────────────────────────────
    existing = (
        db.query(Claim)
        .filter(
            Claim.food_id == payload.food_id,
            Claim.claimer_id == current_user.id,
            Claim.status.in_([ClaimStatus.PENDING, ClaimStatus.APPROVED]),
        )
        .first()
    )
    if existing:
        raise HTTPException(status_code=409, detail="You already have an active claim for this food")

    claim = Claim(
        food_id=payload.food_id,
        claimer_id=current_user.id,
        notes=payload.notes,
        status=ClaimStatus.PENDING,
    )
    food.status = FoodStatus.CLAIMED
    db.add(claim)
    db.commit()
    db.refresh(claim)

    logger.info(f"Claim #{claim.id} created by user #{current_user.id} for food #{food.id}")

    # Notify donor
    notif = NotificationService(db)
    notif.send(
        user_id=food.donor_id,
        ntype="claim_approved",
        title="New Claim Received",
        message=f"{current_user.full_name} claimed '{food.title}'",
        reference_id=claim.id,
        reference_type="claim",
    )
    db.commit()

    return claim


@router.get("/", response_model=list[ClaimOut])
def list_my_claims(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """List claims — receivers see their own claims, donors see claims on their food."""
    if current_user.role in (UserRole.NGO, UserRole.ORPHANAGE):
        claims = db.query(Claim).filter(Claim.claimer_id == current_user.id).all()
    elif current_user.role == UserRole.DONOR:
        food_ids = [f.id for f in current_user.food_listings]
        claims = db.query(Claim).filter(Claim.food_id.in_(food_ids)).all()
    else:  # admin
        claims = db.query(Claim).all()
    return claims


@router.get("/{claim_id}", response_model=ClaimOut)
def get_claim(
    claim_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    claim = db.query(Claim).filter(Claim.id == claim_id).first()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    return claim


@router.patch("/{claim_id}/approve", response_model=ClaimOut)
def approve_claim(
    claim_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Donor approves a pending claim and issues a pickup code."""
    claim = db.query(Claim).filter(Claim.id == claim_id).first()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")

    food = claim.food
    if food.donor_id != current_user.id and current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Not your food listing")
    if claim.status != ClaimStatus.PENDING:
        raise HTTPException(status_code=400, detail="Claim is not pending")

    code = generate_pickup_code()
    claim.status = ClaimStatus.APPROVED
    claim.pickup_code = code
    db.commit()
    db.refresh(claim)

    notif = NotificationService(db)
    notif.claim_approved(claim.claimer_id, food.title, claim.id, code)
    db.commit()

    logger.info(f"Claim #{claim.id} approved, pickup code: {code}")
    return claim


@router.patch("/{claim_id}/reject", response_model=ClaimOut)
def reject_claim(
    claim_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Donor rejects a claim — food goes back to AVAILABLE."""
    claim = db.query(Claim).filter(Claim.id == claim_id).first()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")

    food = claim.food
    if food.donor_id != current_user.id and current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Not your food listing")
    if claim.status != ClaimStatus.PENDING:
        raise HTTPException(status_code=400, detail="Claim is not pending")

    claim.status = ClaimStatus.REJECTED
    food.status = FoodStatus.AVAILABLE  # re-open for new claims
    db.commit()
    db.refresh(claim)

    notif = NotificationService(db)
    notif.claim_rejected(claim.claimer_id, food.title, claim.id)
    db.commit()

    return claim


@router.post("/{claim_id}/pickup", response_model=ClaimOut)
def confirm_pickup(
    claim_id: int,
    payload: PickupConfirm,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Claimer confirms pickup with the OTP code provided by donor."""
    claim = db.query(Claim).filter(Claim.id == claim_id).first()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    if claim.claimer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not your claim")
    if claim.status != ClaimStatus.APPROVED:
        raise HTTPException(status_code=400, detail="Claim is not approved")
    if claim.pickup_code != payload.pickup_code:
        raise HTTPException(status_code=400, detail="Invalid pickup code")

    claim.status = ClaimStatus.PICKED_UP
    claim.pickup_confirmed_at = datetime.now(timezone.utc)
    claim.food.status = FoodStatus.PICKED

    db.commit()
    db.refresh(claim)

    notif = NotificationService(db)
    notif.food_picked(claim.food.donor_id, claim.food.title, claim.food_id)
    db.commit()

    logger.info(f"Pickup confirmed: Claim #{claim.id}, Food #{claim.food_id}")
    return claim
