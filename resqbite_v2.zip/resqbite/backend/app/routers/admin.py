"""
ResQBite — Admin Router
GET  /admin/stats           Platform-wide stats
GET  /admin/users           All users with filters
PATCH /admin/users/{id}     Update user status/role
GET  /admin/food            All food listings
GET  /admin/claims          All claims
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional

from app.core.database import get_db
from app.core.security import require_roles
from app.models.user import User, UserRole
from app.models.food import FoodListing, FoodStatus
from app.models.claim import Claim, ClaimStatus
from app.schemas.schemas import AdminStatsOut, UserOut, UserAdminUpdate, FoodOut, ClaimOut

router = APIRouter()
_admin = require_roles("admin")


@router.get("/stats", response_model=AdminStatsOut)
def platform_stats(db: Session = Depends(get_db), _=Depends(_admin)):
    users = db.query(User).all()
    food  = db.query(FoodListing).all()
    claims = db.query(Claim).all()
    return AdminStatsOut(
        total_users=len(users),
        total_donors=sum(1 for u in users if u.role == UserRole.DONOR),
        total_ngos=sum(1 for u in users if u.role == UserRole.NGO),
        total_orphanages=sum(1 for u in users if u.role == UserRole.ORPHANAGE),
        total_food_listings=len(food),
        available_food=sum(1 for f in food if f.status == FoodStatus.AVAILABLE),
        claimed_food=sum(1 for f in food if f.status == FoodStatus.CLAIMED),
        picked_food=sum(1 for f in food if f.status == FoodStatus.PICKED),
        expired_food=sum(1 for f in food if f.status == FoodStatus.EXPIRED),
        total_claims=len(claims),
        successful_pickups=sum(1 for c in claims if c.status == ClaimStatus.PICKED_UP),
    )


@router.get("/users", response_model=list[UserOut])
def list_all_users(
    role: Optional[str] = None,
    is_active: Optional[bool] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    _=Depends(_admin),
):
    query = db.query(User)
    if role:
        query = query.filter(User.role == role)
    if is_active is not None:
        query = query.filter(User.is_active == is_active)
    return query.offset(skip).limit(limit).all()


@router.patch("/users/{user_id}", response_model=UserOut)
def admin_update_user(
    user_id: int,
    payload: UserAdminUpdate,
    db: Session = Depends(get_db),
    _=Depends(_admin),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(user, field, value)
    db.commit()
    db.refresh(user)
    return user


@router.get("/food", response_model=list[FoodOut])
def list_all_food(
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    _=Depends(_admin),
):
    query = db.query(FoodListing)
    if status:
        query = query.filter(FoodListing.status == status)
    return query.offset(skip).limit(limit).all()


@router.get("/claims", response_model=list[ClaimOut])
def list_all_claims(
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    _=Depends(_admin),
):
    query = db.query(Claim)
    if status:
        query = query.filter(Claim.status == status)
    return query.offset(skip).limit(limit).all()


@router.delete("/food/{food_id}", status_code=204)
def admin_delete_food(food_id: int, db: Session = Depends(get_db), _=Depends(_admin)):
    food = db.query(FoodListing).filter(FoodListing.id == food_id).first()
    if not food:
        raise HTTPException(status_code=404, detail="Not found")
    db.delete(food)
    db.commit()
