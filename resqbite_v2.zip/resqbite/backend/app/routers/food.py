"""
ResQBite — Food Router
POST   /food/             Create food listing
GET    /food/             List food (with geo filter)
GET    /food/{id}         Get food detail
PATCH  /food/{id}         Update listing (donor only)
DELETE /food/{id}         Remove listing (donor/admin)
GET    /food/dashboard    Donor dashboard summary
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from datetime import datetime, timezone, timedelta
from typing import Optional
import logging

from app.core.database import get_db
from app.core.security import get_current_user, require_roles
from app.core.config import settings
from app.models.food import FoodListing, FoodStatus
from app.models.user import UserRole
from app.schemas.schemas import FoodCreate, FoodOut, FoodUpdate, FoodListResponse
from app.utils.geo import filter_by_radius
from app.services.notification_service import NotificationService

router = APIRouter()
logger = logging.getLogger(__name__)


def _require_donor_or_admin(current_user=Depends(get_current_user)):
    if current_user.role not in (UserRole.DONOR, UserRole.ADMIN):
        raise HTTPException(status_code=403, detail="Donors and admins only")
    return current_user


@router.post("/", response_model=FoodOut, status_code=201)
def create_food(
    payload: FoodCreate,
    db: Session = Depends(get_db),
    current_user=Depends(_require_donor_or_admin),
):
    """Create a new food listing. NGO priority window starts immediately."""
    ngo_window = datetime.now(timezone.utc) + timedelta(
        minutes=settings.NGO_PRIORITY_WINDOW_MINUTES
    )

    food = FoodListing(
        donor_id=current_user.id,
        title=payload.title,
        description=payload.description,
        category=payload.category,
        quantity=payload.quantity,
        serves=payload.serves,
        image_url=payload.image_url,
        expiry_time=payload.expiry_time,
        pickup_by=payload.pickup_by,
        pickup_address=payload.pickup_address,
        latitude=payload.latitude,
        longitude=payload.longitude,
        is_vegetarian=payload.is_vegetarian,
        is_vegan=payload.is_vegan,
        is_halal=payload.is_halal,
        is_kosher=payload.is_kosher,
        status=FoodStatus.AVAILABLE,
        ngo_window_open=True,
        ngo_window_expires_at=ngo_window,
    )
    db.add(food)
    db.commit()
    db.refresh(food)
    logger.info(f"Food created: #{food.id} by donor #{current_user.id}")

    # Notify nearby NGOs/Orphanages (in production: broadcast to subscribed users)
    # Here we just log; plug in push/email service
    return food


@router.get("/", response_model=FoodListResponse)
def list_food(
    lat: Optional[float] = Query(None, description="Your latitude"),
    lon: Optional[float] = Query(None, description="Your longitude"),
    radius_km: float = Query(settings.DEFAULT_SEARCH_RADIUS_KM, ge=0.1, le=500),
    status: Optional[str] = Query("available"),
    category: Optional[str] = None,
    vegetarian: Optional[bool] = None,
    vegan: Optional[bool] = None,
    halal: Optional[bool] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    List food with optional geo filtering and dietary filters.
    NGOs only see listings during their priority window or after.
    Orphanages only see listings after the NGO window has closed.
    """
    query = db.query(FoodListing)

    if status:
        query = query.filter(FoodListing.status == status)
    if category:
        query = query.filter(FoodListing.category == category)
    if vegetarian is not None:
        query = query.filter(FoodListing.is_vegetarian == vegetarian)
    if vegan is not None:
        query = query.filter(FoodListing.is_vegan == vegan)
    if halal is not None:
        query = query.filter(FoodListing.is_halal == halal)

    # Priority enforcement for orphanages
    if current_user.role == UserRole.ORPHANAGE:
        query = query.filter(FoodListing.ngo_window_open == False)

    listings = query.order_by(FoodListing.created_at.desc()).all()

    # Geo filter
    if lat is not None and lon is not None:
        geo_results = filter_by_radius(listings, lat, lon, radius_km)
        items_with_dist = geo_results[skip: skip + limit]
        total = len(geo_results)
        out = []
        for food, dist in items_with_dist:
            d = FoodOut.model_validate(food)
            d.distance_km = round(dist, 2)
            out.append(d)
    else:
        total = len(listings)
        out = [FoodOut.model_validate(f) for f in listings[skip: skip + limit]]

    return FoodListResponse(total=total, items=out)


@router.get("/dashboard/summary")
def donor_dashboard(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("donor", "admin")),
):
    """Donor dashboard: stats on their listings."""
    listings = db.query(FoodListing).filter(FoodListing.donor_id == current_user.id).all()
    return {
        "total": len(listings),
        "available": sum(1 for f in listings if f.status == FoodStatus.AVAILABLE),
        "claimed":   sum(1 for f in listings if f.status == FoodStatus.CLAIMED),
        "picked":    sum(1 for f in listings if f.status == FoodStatus.PICKED),
        "expired":   sum(1 for f in listings if f.status == FoodStatus.EXPIRED),
        "serves_total": sum(f.serves or 0 for f in listings if f.status == FoodStatus.PICKED),
    }


@router.get("/{food_id}", response_model=FoodOut)
def get_food(food_id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    food = db.query(FoodListing).filter(FoodListing.id == food_id).first()
    if not food:
        raise HTTPException(status_code=404, detail="Food listing not found")
    return food


@router.patch("/{food_id}", response_model=FoodOut)
def update_food(
    food_id: int,
    payload: FoodUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    food = db.query(FoodListing).filter(FoodListing.id == food_id).first()
    if not food:
        raise HTTPException(status_code=404, detail="Food listing not found")
    if food.donor_id != current_user.id and current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Not your listing")
    if food.status != FoodStatus.AVAILABLE:
        raise HTTPException(status_code=400, detail="Cannot edit non-available listing")

    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(food, field, value)

    db.commit()
    db.refresh(food)
    return food


@router.delete("/{food_id}", status_code=204)
def delete_food(
    food_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    food = db.query(FoodListing).filter(FoodListing.id == food_id).first()
    if not food:
        raise HTTPException(status_code=404, detail="Not found")
    if food.donor_id != current_user.id and current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Not authorized")
    db.delete(food)
    db.commit()
