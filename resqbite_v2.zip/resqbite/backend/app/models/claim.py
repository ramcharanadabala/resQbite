"""
ResQBite — Claim Model
"""
from sqlalchemy import Column, Integer, String, Text, DateTime, Enum, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum

from app.core.database import Base


class ClaimStatus(str, enum.Enum):
    PENDING   = "pending"
    APPROVED  = "approved"
    REJECTED  = "rejected"
    CANCELLED = "cancelled"
    PICKED_UP = "picked_up"


class Claim(Base):
    __tablename__ = "claims"

    id         = Column(Integer, primary_key=True, index=True)
    food_id    = Column(Integer, ForeignKey("food_listings.id"), nullable=False)
    claimer_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    status = Column(Enum(ClaimStatus), default=ClaimStatus.PENDING, index=True)
    notes  = Column(Text, nullable=True)

    # Pickup confirmation
    pickup_confirmed_at = Column(DateTime(timezone=True), nullable=True)
    pickup_code         = Column(String(10), nullable=True)   # 6-digit OTP for pickup

    # Timestamps
    claimed_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    food    = relationship("FoodListing", back_populates="claims")
    claimer = relationship("User",        back_populates="claims")

    def __repr__(self):
        return f"<Claim id={self.id} food_id={self.food_id} status={self.status}>"
