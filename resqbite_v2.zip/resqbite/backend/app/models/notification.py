"""
ResQBite — Notification Model
"""
from sqlalchemy import Column, Integer, String, Text, DateTime, Enum, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum

from app.core.database import Base


class NotificationType(str, enum.Enum):
    FOOD_AVAILABLE   = "food_available"
    CLAIM_APPROVED   = "claim_approved"
    CLAIM_REJECTED   = "claim_rejected"
    PICKUP_REMINDER  = "pickup_reminder"
    FOOD_EXPIRED     = "food_expired"
    ACCOUNT_VERIFIED = "account_verified"
    SYSTEM           = "system"


class Notification(Base):
    __tablename__ = "notifications"

    id      = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    type    = Column(Enum(NotificationType), nullable=False)
    title   = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)

    # Optional reference
    reference_id   = Column(Integer, nullable=True)   # food_id or claim_id
    reference_type = Column(String(50), nullable=True) # "food" or "claim"

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    user = relationship("User", back_populates="notifications")

    def __repr__(self):
        return f"<Notification id={self.id} user_id={self.user_id} type={self.type}>"
