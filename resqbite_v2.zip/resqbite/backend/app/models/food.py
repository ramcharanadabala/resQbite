"""
ResQBite — Food Listing Model
"""
from sqlalchemy import (
    Column, Integer, String, Text, Float, Boolean,
    DateTime, Enum, ForeignKey
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum

from app.core.database import Base


class FoodStatus(str, enum.Enum):
    AVAILABLE = "available"
    CLAIMED   = "claimed"
    PICKED    = "picked"
    EXPIRED   = "expired"


class FoodCategory(str, enum.Enum):
    COOKED      = "cooked"
    RAW         = "raw"
    PACKAGED    = "packaged"
    BAKERY      = "bakery"
    DAIRY       = "dairy"
    VEGETABLES  = "vegetables"
    FRUITS      = "fruits"
    BEVERAGES   = "beverages"
    OTHER       = "other"


class FoodListing(Base):
    __tablename__ = "food_listings"

    id          = Column(Integer, primary_key=True, index=True)
    donor_id    = Column(Integer, ForeignKey("users.id"), nullable=False)

    # Food details
    title       = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    category    = Column(Enum(FoodCategory), default=FoodCategory.OTHER)
    quantity    = Column(String(100), nullable=False)   # e.g. "5 kg", "20 portions"
    serves      = Column(Integer, nullable=True)         # estimated number of people served
    image_url   = Column(String(500), nullable=True)

    # Status
    status = Column(Enum(FoodStatus), default=FoodStatus.AVAILABLE, index=True)

    # Timing
    prepared_at  = Column(DateTime(timezone=True), nullable=True)
    expiry_time  = Column(DateTime(timezone=True), nullable=False, index=True)
    pickup_by    = Column(DateTime(timezone=True), nullable=True)

    # NGO Priority Window
    ngo_window_open       = Column(Boolean, default=True)
    ngo_window_expires_at = Column(DateTime(timezone=True), nullable=True)

    # Geo-location of pickup
    pickup_address = Column(Text, nullable=True)
    latitude       = Column(Float, nullable=False)
    longitude      = Column(Float, nullable=False)

    # Dietary flags
    is_vegetarian = Column(Boolean, default=False)
    is_vegan      = Column(Boolean, default=False)
    is_halal      = Column(Boolean, default=False)
    is_kosher     = Column(Boolean, default=False)

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    donor  = relationship("User",  back_populates="food_listings", foreign_keys=[donor_id])
    claims = relationship("Claim", back_populates="food")

    def __repr__(self):
        return f"<FoodListing id={self.id} title={self.title} status={self.status}>"
