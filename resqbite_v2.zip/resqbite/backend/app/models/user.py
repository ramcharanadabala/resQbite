"""
ResQBite — User Model
"""
from sqlalchemy import Column, Integer, String, Boolean, Float, DateTime, Enum, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum

from app.core.database import Base


class UserRole(str, enum.Enum):
    DONOR     = "donor"
    NGO       = "ngo"
    ORPHANAGE = "orphanage"
    ADMIN     = "admin"


class User(Base):
    __tablename__ = "users"

    id            = Column(Integer, primary_key=True, index=True)
    email         = Column(String(255), unique=True, index=True, nullable=False)
    full_name     = Column(String(255), nullable=False)
    phone         = Column(String(20), nullable=True)
    password_hash = Column(String(255), nullable=False)
    role          = Column(Enum(UserRole), nullable=False)
    is_active     = Column(Boolean, default=True)
    is_verified   = Column(Boolean, default=False)

    # Organization details (NGO / Orphanage)
    organization_name = Column(String(255), nullable=True)
    registration_no   = Column(String(100), nullable=True)
    address           = Column(Text, nullable=True)

    # Geo-location
    latitude  = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    food_listings = relationship("FoodListing", back_populates="donor", foreign_keys="FoodListing.donor_id")
    claims        = relationship("Claim",        back_populates="claimer")
    notifications = relationship("Notification", back_populates="user")

    def __repr__(self):
        return f"<User id={self.id} email={self.email} role={self.role}>"
