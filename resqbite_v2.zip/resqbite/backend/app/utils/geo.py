"""
ResQBite — Geo Utilities
Haversine distance calculation for proximity-based food search.
"""
import math
from typing import List, Tuple, Optional


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate the great-circle distance between two points on Earth.
    Returns distance in kilometres.
    """
    R = 6371.0  # Earth radius in km

    φ1, φ2 = math.radians(lat1), math.radians(lat2)
    Δφ = math.radians(lat2 - lat1)
    Δλ = math.radians(lon2 - lon1)

    a = math.sin(Δφ / 2) ** 2 + math.cos(φ1) * math.cos(φ2) * math.sin(Δλ / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return R * c


def filter_by_radius(
    items,
    center_lat: float,
    center_lon: float,
    radius_km: float,
    lat_attr: str = "latitude",
    lon_attr: str = "longitude",
) -> List[Tuple[any, float]]:
    """
    Filter a list of ORM objects by geo radius.
    Returns list of (item, distance_km) tuples sorted by distance.
    """
    results = []
    for item in items:
        item_lat = getattr(item, lat_attr, None)
        item_lon = getattr(item, lon_attr, None)
        if item_lat is None or item_lon is None:
            continue
        dist = haversine_km(center_lat, center_lon, item_lat, item_lon)
        if dist <= radius_km:
            results.append((item, dist))

    results.sort(key=lambda x: x[1])
    return results
